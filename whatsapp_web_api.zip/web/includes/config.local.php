<?php
declare(strict_types=1);

return [
    'app_env' => 'development',
    'base_url' => 'http://localhost/whatsapp_web_api/web',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'whatsapp_bot',
        'user' => 'root',
        'pass' => '070817',
        'charset' => 'utf8mb4',
    ],
    'session' => [
        'secure' => false,
    ],
];
