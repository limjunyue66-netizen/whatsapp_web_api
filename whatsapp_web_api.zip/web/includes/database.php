<?php
/**
 * REAL database config — edit these for cPanel / local MySQL.
 * This file is gitignored (secrets stay on the server only).
 */
declare(strict_types=1);

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'synergy1_whatsapp_web_api_lim',
    'user' => 'synergy1_shaoxi',
    'pass' => 'p07e&61#5e9^c]Y}',
    'charset' => 'utf8mb4',
];
